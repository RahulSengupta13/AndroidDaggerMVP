# AndroidDaggerMVP
An application showcasing MVP principles with Dagger2
