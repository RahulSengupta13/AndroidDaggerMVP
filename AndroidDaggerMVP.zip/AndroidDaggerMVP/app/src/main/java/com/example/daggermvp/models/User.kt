package com.example.daggermvp.models

data class User(val id: Int, val name: String, val username: String)