package com.example.daggermvp.utils

class ConstantsUtils {
    companion object {
        const val BASE_URL = "https://jsonplaceholder.typicode.com/"
    }
}