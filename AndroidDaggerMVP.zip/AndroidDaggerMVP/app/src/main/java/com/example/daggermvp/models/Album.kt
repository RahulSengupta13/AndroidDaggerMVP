package com.example.daggermvp.models

data class Album(val id: Int, val userId: Int, val title: String)